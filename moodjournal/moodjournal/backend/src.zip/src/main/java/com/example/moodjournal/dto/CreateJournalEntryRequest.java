package com.example.moodjournal.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class CreateJournalEntryRequest {
    @NotBlank(message = "Title cannot be empty")
    @Size(max = 100, message = "Title must be less than 100 characters")
    private String title;

    @NotBlank(message = "Content cannot be empty")
    private String content;

    @Pattern(regexp = "HAPPY|SAD|ANGRY|NEUTRAL|SURPRISED", message = "Invalid mood")
    private String mood;

    @Pattern(regexp = "PRIVATE|PUBLIC", message = "Invalid visibility")
    private String visibility;

    // Optional AI analysis metadata
    // emotion returned by AI (e.g., positive/neutral/negative)
    private String analysisEmotion;
    // confidence or polarity score (0.0 - 1.0)
    private Double analysisConfidence;
    // intensity or subjectivity score (0.0 - 1.0)
    private Double analysisIntensity;
}
