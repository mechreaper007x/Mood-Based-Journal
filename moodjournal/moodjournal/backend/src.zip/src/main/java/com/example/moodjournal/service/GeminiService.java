package com.example.moodjournal.service;

import com.example.moodjournal.dto.GeminiResponse;
import com.example.moodjournal.util.PromptConstants;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class GeminiService {

  private final RestTemplate restTemplate = new RestTemplate();
  private final ObjectMapper objectMapper = new ObjectMapper();

  @Value("${google.api.key}")
  private String apiKey;

  @Value("${google.api.url}")
  private String apiUrl;

  public String getEmotionBreakdown(String text) {
    return callGeminiApi(
      PromptConstants.EMOTION_BREAKDOWN_PROMPT,
      "Analyze this entry: " + text
    );
  }

  public String getDailyQuote() {
    return callGeminiApi(
      PromptConstants.DAILY_QUOTE_PROMPT,
      "Give me a quote of the day."
    );
  }

  public String suggestMood(String text) {
    return callGeminiApi(
      PromptConstants.SUGGEST_MOOD_PROMPT,
      "Suggest a mood for this entry: " + text
    );
  }

  private String callGeminiApi(String systemPrompt, String userQuery) {
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);

    Map<String, Object> requestBodyMap = Map.of(
      "contents",
      List.of(Map.of("parts", List.of(Map.of("text", userQuery)))),
      "systemInstruction",
      Map.of("parts", List.of(Map.of("text", systemPrompt))),
      "generationConfig",
      Map.of("responseMimeType", "application/json")
    );

    try {
      String requestBody = objectMapper.writeValueAsString(requestBodyMap);
      HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);
      String url = apiUrl + "?key=" + apiKey;
      ResponseEntity<String> response = restTemplate.postForEntity(
        url,
        entity,
        String.class
      );
      return extractJsonFromResponse(response.getBody());
    } catch (Exception e) {
      System.err.println("Error calling AI service: " + e.getMessage());
      return "{\"error\": \"Failed to call AI service: " +
      e.getMessage() +
      "\"}";
    }
  }

  private String extractJsonFromResponse(String responseBody) {
    try {
      GeminiResponse geminiResponse = objectMapper.readValue(
        responseBody,
        GeminiResponse.class
      );
      if (
        geminiResponse != null &&
        geminiResponse.getCandidates() != null &&
        !geminiResponse.getCandidates().isEmpty()
      ) {
        return geminiResponse
          .getCandidates()
          .get(0)
          .getContent()
          .getParts()
          .get(0)
          .getText();
      }
      return "[]";
    } catch (Exception e) {
      System.err.println("Failed to parse AI response: " + responseBody);
      return "{\"error\": \"Failed to parse AI response\"}";
    }
  }
}
