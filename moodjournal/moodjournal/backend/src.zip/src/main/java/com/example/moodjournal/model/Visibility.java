package com.example.moodjournal.model;

public enum Visibility {
    PRIVATE, PUBLIC_ANON, PUBLIC, FRIENDS_ONLY
}
