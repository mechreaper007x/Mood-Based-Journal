package com.example.moodjournal.service;

import com.example.moodjournal.dto.UpdateJournalEntryRequest;
import com.example.moodjournal.model.JournalEntry;
import com.example.moodjournal.model.Mood;
import com.example.moodjournal.model.User;
import com.example.moodjournal.model.Visibility;
import com.example.moodjournal.repository.JournalEntryRepository;
import com.example.moodjournal.repository.UserRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import org.springframework.stereotype.Service;

@Service
public class JournalEntryService {

  private final JournalEntryRepository entryRepo;
  private final UserRepository userRepo;
  private final GeminiService geminiService;
  private final ObjectMapper objectMapper;

  public JournalEntryService(
    JournalEntryRepository entryRepo,
    UserRepository userRepo,
    GeminiService geminiService,
    ObjectMapper objectMapper
  ) {
    this.entryRepo = entryRepo;
    this.userRepo = userRepo;
    this.geminiService = geminiService;
    this.objectMapper = objectMapper;
  }

  public JournalEntry create(Long userId, JournalEntry entry) {
    User user = userRepo
      .findById(userId)
      .orElseThrow(() -> new NoSuchElementException("User not found with id: " + userId));
    entry.setUser(user);

    if (entry.getMood() == null) {
      entry.setMood(suggestMood(entry.getContent()));
    }

    return entryRepo.save(entry);
  }

  public Mood suggestMood(String content) {
    try {
      String emotionJson = geminiService.getEmotionBreakdown(content).join();
      Map<String, Object> analysis = objectMapper.readValue(
        emotionJson,
        new TypeReference<Map<String, Object>>() {}
      );
      Map<String, Double> moods = (Map<String, Double>) analysis.get("moods");
      if (moods != null && !moods.isEmpty()) {
        return moods
          .entrySet()
          .stream()
          .max(Map.Entry.comparingByValue())
          .map(entry -> Mood.valueOf(entry.getKey().toUpperCase()))
          .orElse(Mood.NEUTRAL);
      }
    } catch (Exception e) {
      // Log error
    }
    return Mood.NEUTRAL;
  }

  public List<JournalEntry> getByUser(Long userId) {
    return entryRepo.findByUserId(userId);
  }

  public List<JournalEntry> getPublicEntries(String mood) {
    if (mood != null && !mood.isEmpty()) {
      try {
        Mood moodEnum = Mood.valueOf(mood.toUpperCase());
        return entryRepo.findByMoodAndVisibility(moodEnum, Visibility.PUBLIC_ANON);
      } catch (IllegalArgumentException e) {
        return List.of();
      }
    }
    return entryRepo.findByVisibility(Visibility.PUBLIC_ANON);
  }

  public Optional<JournalEntry> getById(Long id, Long userId) {
    return entryRepo
      .findById(id)
      .map(entry -> {
        if (!entry.getUser().getId().equals(userId)) {
          throw new NoSuchElementException("JournalEntry not found");
        }
        return entry;
      });
  }

  public JournalEntry update(
    Long id,
    Long userId,
    UpdateJournalEntryRequest updated
  ) {
    return entryRepo
      .findById(id)
      .map(e -> {
        if (!e.getUser().getId().equals(userId)) {
          throw new NoSuchElementException("JournalEntry not found");
        }
        e.setTitle(updated.getTitle());
        e.setContent(updated.getContent());

        if (updated.getContent() != null && !updated.getContent().equals(e.getContent())) {
          Mood suggestedMood = suggestMood(updated.getContent());
          if (updated.getMood() == null || updated.getMood().isBlank() || e.getMood() == null) {
            e.setMood(suggestedMood);
          }
        }

        if (updated.getMood() != null && !updated.getMood().isBlank()) {
          try {
            e.setMood(Mood.valueOf(updated.getMood().toUpperCase()));
          } catch (IllegalArgumentException ex) {}
        }
        if (updated.getVisibility() != null && !updated.getVisibility().isBlank()) {
          try {
            e.setVisibility(Visibility.valueOf(updated.getVisibility().toUpperCase()));
          } catch (IllegalArgumentException ex) {}
        }
        return entryRepo.save(e);
      })
      .orElseThrow(() -> new NoSuchElementException("JournalEntry not found"));
  }

  public JournalEntry updateJournal(Long id, JournalEntry updatedEntry) {
    return entryRepo
      .findById(id)
      .map(e -> {
        e.setTitle(updatedEntry.getTitle());
        e.setContent(updatedEntry.getContent());
        e.setMood(updatedEntry.getMood());
        e.setVisibility(updatedEntry.getVisibility());
        return entryRepo.save(e);
      })
      .orElseThrow(() -> new NoSuchElementException("JournalEntry not found"));
  }

  public void delete(Long id, Long userId) {
    entryRepo
      .findById(id)
      .ifPresentOrElse(
        entry -> {
          if (!entry.getUser().getId().equals(userId)) {
            throw new NoSuchElementException("JournalEntry not found");
          }
          entryRepo.deleteById(id);
        },
        () -> {
          throw new NoSuchElementException("JournalEntry not found");
        }
      );
  }
}