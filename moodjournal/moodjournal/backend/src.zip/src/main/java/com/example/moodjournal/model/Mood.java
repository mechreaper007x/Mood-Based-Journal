package com.example.moodjournal.model;

public enum Mood {
    HAPPY, SAD, ANXIOUS, ANGRY, CALM, NEUTRAL, JOYFUL, PRODUCTIVE
}
